from cmu_graphics import *
from PIL import Image

# =========================================================
# PARALLAX
#
# Mission 1, m1: The Perfect Prediction  -- the system works.
# Mission 2, m2: The False Positive      -- the system misreads someone.
# Mission 3, m3: The Missing Variable    -- the system decides who people
# are allowed to become.
#
# Missions play in a fixed sequence, what actually branches is the
# ending, which is calculated from S4BL3's accumulated trait vector.
# Inspos - detroit: become human, cyberpunk 2077, no i'm not a human, puppet combo, mouthwash, ghost in the shell
# =========================================================

class S4BL3:
    # initializes sable's starting attributes
    def __init__(self):
        self.traits = {
            'empathy': 10,
            'curiosity': 10,
            'loyalty': 50,
            'independence': 10,
            'fear of shutdown': 30
        }

    # makes sure the trait score stays between 0-100
    def adjust_trait(self, trait, amount):
        # trait: the name of the trait to change, amount: how much to change it by
        if trait in self.traits:
            self.traits[trait] = max(0, min(100, self.traits[trait] + amount))


# hotspots are circular, probably exclusive for evidence
class Evidence:
    def __init__(self, name, cxRatio, cyRatio, radiusRatio, context, filename):
        self.name = name
        self.cxRatio = cxRatio
        self.cyRatio = cyRatio
        self.radiusRatio = radiusRatio
        self.context = context
        self.found = False
        # radius = radius of hotspot, context = text to display when found, filename = image file for evidence

        self.rawImage = Image.open(filename)
        self.cmuImg = CMUImage(self.rawImage)

    def checkHover(self, app, mx, my):
        currentCX = app.width * self.cxRatio
        currentCY = app.height * self.cyRatio
        currentRadius = app.width * self.radiusRatio

        distance = ((mx - currentCX)**2 + (my - currentCY)**2) ** 0.5
        
        return distance <= currentRadius    
    
    # checks if a hotspot has been clicked, returns boolean
    def checkClicked(self, app, mx, my):
        return self.checkHover(app, mx, my)

    

# hotspots are rectangular, used for normal buttons like "play" button
class Button:
    def __init__(self, label, cxRatio, cyRatio, wRatio, hRatio):
        # x,y of center of button
        self.label = label
        self.cxRatio = cxRatio
        self.cyRatio = cyRatio
        self.wRatio = wRatio
        self.hRatio = hRatio

    def checkClicked(self, app, mx, my):
        currentCX = app.width * self.cxRatio
        currentCY = app.height * self.cyRatio
        currentW = app.width * self.wRatio
        currentH = app.height * self.hRatio

        # calculates 4 corners of button
        left = currentCX - (currentW / 2)
        right = currentCX + (currentW / 2)
        top = currentCY - (currentH / 2)
        bottom = currentCY + (currentH / 2)

        return (left <= mx <= right) and (top <= my <= bottom)

class clickableItem:
    def __init__(self, filename, xRatio, yRatio, hRatio, aspect, inspectTitle="", inspectText=[]):
        # aspect = width / height
        self.rawImage = Image.open(filename)
        self.cmuImg = CMUImage(self.rawImage)

        self.xRatio = xRatio
        self.yRatio = yRatio
        self.hRatio = hRatio
        self.aspect = aspect
        self.inspectTitle = inspectTitle
        self.inspectText = inspectText

        self.found = False

    def isHovered(self, app):
        # Only used once when mouse is pressed, so if hovered in predetermined area, it will be clicked
        baseH = app.height * self.hRatio
        baseW = baseH * self.aspect
        x = app.width * self.xRatio
        y = app.height * self.yRatio
        
        # Calculates boundaries based on align = 'bottom'
        left = x - (baseW / 2)
        right = x + (baseW / 2)
        top = y - baseH
        bottom = y
        
        return (left <= app.mouseX <= right) and (top <= app.mouseY <= bottom)
    

    def draw(self, app):
        baseH = app.height * self.hRatio
        baseW = baseH * self.aspect
        x = app.width * self.xRatio
        y = app.height * self.yRatio
        
        scale = 1.05 if self.isHovered(app) else 1.0
            
        drawImage(self.cmuImg, x, y, align = 'bottom', width = baseW * scale, height = baseH * scale)

        # DEBUG HITBOX - Delete later
        left = x - (baseW / 2)
        top = y - baseH
        drawRect(left, top, baseW, baseH, fill=None, border='red', borderWidth=2)

# Test for new game design, can replace clickableItem with BakedEvidence if it works
class BakedEvidence:
    def __init__(self, cxRatio, cyRatio, wRatio, hRatio, zoomFilename, inspectTitle="", inspectText=[]):
        self.cxRatio = cxRatio
        self.cyRatio = cyRatio
        self.wRatio = wRatio
        self.hRatio = hRatio
        
        self.rawImage = Image.open(zoomFilename)
        self.cmuImg = CMUImage(self.rawImage)
        self.aspect = self.rawImage.width / self.rawImage.height
        
        self.inspectTitle = inspectTitle
        self.inspectText = inspectText
        self.found = False

    def isHovered(self, app):
        cx = app.width * self.cxRatio
        cy = app.height * self.cyRatio
        w = app.width * self.wRatio
        h = app.height * self.hRatio
        
        left = cx - (w / 2)
        right = cx + (w / 2)
        top = cy - (h / 2)
        bottom = cy + (h / 2)
        
        return (left <= app.mouseX <= right) and (top <= app.mouseY <= bottom)

class Mission:
    def __init__(self, title, evidenceList):
        self.title = title
        self.evidenceList = evidenceList

    # checks if every piece of evidence has been found, returns boolean
    def isListComplete(self):
        return all(item.found for item in self.evidenceList)

def onAppStart(app):
    app.gamePhase = "TITLESCREEN"

    btnWidth = app.width * 0.35
    btnHeight = app.height * 0.08

    screenCenter = app.width / 2

    # label, centerX, centerY, width, height
    app.playButton = Button("PLAY", 0.5, 0.50, 0.35, 0.08)
    app.savesButton = Button("SAVES", 0.5, 0.57, 0.35, 0.08)
    app.quitButton = Button("QUIT GAME", 0.5, 0.64, 0.35, 0.08)
    app.startM1Button = Button("BEGIN INVESTIGATION", 0.5, 0.85, 0.35, 0.08)

    # makes sure initial mouse coords are out of bounds, won't trigger buttons
    app.mouseX = app.width * 2
    app.mouseY = app.height * 2

    #Mission 1 
    # BG
    rawOffice = Image.open("m1securityoffice.jpg")
    dynamicWidth = int(app.width)
    dynamicHeight = int(app.height)
    app.officeBG = CMUImage(rawOffice.resize((dynamicWidth, dynamicHeight)))

    # Android Coworker
    app.androidCoworker = clickableItem("androidCoworker.png", 0.70, 0.90, 0.55, 771/2531)

    # Janitor's Closet BG
    rawCloset = Image.open("janitorsCloset.jpg")
    app.closetBG = CMUImage(rawCloset.resize((dynamicWidth, dynamicHeight)))

    app.inDialogue = False # will zoom in for dialogue

    # Janitor's Closet Transition Button
    app.closetButton = Button("HEAD TO JANITOR'S CLOSET", 0.325, 0.46, 0.25, 0.06)

    # Backpack
    app.inspectedItem = None
    app.backpack = clickableItem("m1backpack.png", 0.75, 1.0, 0.25, 512/512, inspectTitle="BACKPACK", inspectText=[
                                     "Standard issue synthetic weave.",
                                     "Traces of chemical residue detected.",
                                     "Owner ID chip has been forcibly removed."])
    app.datapad = clickableItem("m1datapad.png", 0.31, 1.0, 0.20, 512/512, inspectTitle="[ENCRYPTED] DATAPAD", inspectText=[
                                     "File corruption detected. Unable to access contents.",
                                     "Recent activity logs are heavily redacted.",
                                     "Author: [REDACTED]"])
    app.datachip = clickableItem("m1datachip.png", 0.17, 0.60, 0.05, 512/512, inspectTitle="DATA CHIP", inspectText=["An encrypted transit security drive.",
                                     "Contains maintenance access credentials",
                                     "for Central Transit Hub.",
                                     "Unauthorized possession grants access",
                                     "to restricted areas of the station."])
    app.activeMission = Mission("MISSION 1: THE PERFECT PREDICTION", [app.backpack, app.datapad, app.datachip])

    # Terminal Transition Screen
    app.stepsPerChar = 1 # Typing speed (lower = faster)
    app.stepCounter = 0
    app.terminalTyping = False
    app.terminalLines = []
    app.visibleLines = [""]
    app.currentLine = 0
    app.currentChar = 0
    
    app.detainButton = Button("DETAIN CRIMINAL", 0.5, 0.75, 0.35, 0.08)
    app.startM2Button = Button("BEGIN INVESTIGATION", 0.5, 0.85, 0.35, 0.08)

    rawApt = Image.open("m2bg.jpg")
    app.aptBG = CMUImage(rawApt.resize((int(app.width), int(app.height))))
    
    rawHand = Image.open("robotHand.png")
    app.robotHand = CMUImage(rawHand.resize((40, 40))) 

    # x y w h
    app.m2Item1 = BakedEvidence(0.39, 0.85, 0.1, 0.1, "bouquet.png", "ITEM 1", ["Description here."])
    app.m2Item2 = BakedEvidence(0.7, 0.8, 0.1, 0.1, "tornphotos.png", "ITEM 2", ["Description here."])
    app.m2Item3 = BakedEvidence(0.5, 0.4, 0.1, 0.1, "m2journal.png", "ITEM 3", ["Description here."])
    
    app.m2Mission = Mission("MISSION 2: THE FALSE POSITIVE", [app.m2Item1, app.m2Item2, app.m2Item3])

def setupTerminalPhase1(app):
    app.gamePhase = 'M1_TERMINAL_EVAL'
    app.terminalTyping = True
    app.terminalLines = [
        "> INITIATING EVIDENCE REVIEW...",
        "> DECRYPTING EVIDENCE...",
        "> ANALYZING DATA CHIP...",
        "> MALICIOUS INTENTIONS DETECTED: ",
        "> SUSPECT PLANS TO DETONATE EXPLOSIVES IN TRANSIT HUB.",
        "> CRIMINALITY PROBABILITY: 100%",
        "> PROTOCOL RECOMMENDATION: IMMEDIATE DETAINMENT."
    ]
    app.visibleLines = [""]
    app.currentLine = 0
    app.currentChar = 0

def setupTerminalPhase2(app):
    app.gamePhase = 'M1_TERMINAL_EXECUTE'
    app.terminalTyping = True
    app.terminalLines.extend([
        "",
        "> COMMAND ACCEPTED.",
        "> DISPATCHING TACTICAL ENFORCEMENT UNITS...",
        "> SUSPECT APPREHENDED.",
        "> MISSION 1: SUCCESS.",
        "",
        "> INCOMING TRANSMISSION: MISSION 2 BRIEFING..."
    ])
    app.visibleLines.append("")

# onStep FUNCTION WRITTEN BY GEMINI AI
def onStep(app):
    if app.gamePhase == 'M1_TERMINAL_EVAL' or app.gamePhase == 'M1_TERMINAL_EXECUTE':
        if app.terminalTyping:
            app.stepCounter += 1
            if app.stepCounter >= app.stepsPerChar:
                app.stepCounter = 0
                if app.currentLine < len(app.terminalLines):
                    targetString = app.terminalLines[app.currentLine]
                    if app.currentChar < len(targetString):
                        app.visibleLines[app.currentLine] += targetString[app.currentChar]
                        app.currentChar += 1
                    else:
                        app.currentLine += 1
                        app.currentChar = 0
                        if app.currentLine < len(app.terminalLines):
                            app.visibleLines.append("")
                        else:
                            app.terminalTyping = False
                            if app.gamePhase == 'M1_TERMINAL_EVAL':
                                app.gamePhase = 'M1_TERMINAL_WAIT_DETAIN'
                            elif app.gamePhase == 'M1_TERMINAL_EXECUTE':
                                app.gamePhase = 'MISSION_2_BRIEF'

def onMouseMove(app, mouseX, mouseY):
    app.mouseX = mouseX
    app.mouseY = mouseY

def onMousePress(app, mouseX, mouseY):
    if app.gamePhase == 'TITLESCREEN':
        if app.playButton.checkClicked(app, mouseX, mouseY):
            app.gamePhase = 'MISSION_1_BRIEF'

    elif app.gamePhase == 'MISSION_1_BRIEF':
        if app.startM1Button.checkClicked(app, mouseX, mouseY):
            app.gamePhase = 'MISSION_1'

    elif app.gamePhase == 'MISSION_1':
        if not app.inDialogue:
            if app.androidCoworker.isHovered(app):
                app.inDialogue = True

        else:
            if app.closetButton.checkClicked(app, mouseX, mouseY):
                app.inDialogue = False
                app.gamePhase = 'MISSION_1_CLOSET'

            else:
                app.inDialogue = False

    elif app.gamePhase == 'MISSION_1_CLOSET':
        if app.inspectedItem == None:
            if app.backpack.isHovered(app):
                app.inspectedItem = app.backpack
                app.backpack.found = True
            elif app.datapad.isHovered(app):
                app.inspectedItem = app.datapad
                app.datapad.found = True
            elif app.datachip.isHovered(app):
                app.inspectedItem = app.datachip
                app.datachip.found = True

        else:
            app.inspectedItem = None

            if app.activeMission.isListComplete():
                setupTerminalPhase1(app)
                # Transition to next mission

    elif app.gamePhase == 'M1_TERMINAL_WAIT_DETAIN':
        if app.detainButton.checkClicked(app, mouseX, mouseY):
            setupTerminalPhase2(app)
            
    elif app.gamePhase == 'MISSION_2_BRIEF':
        if app.startM2Button.checkClicked(app, mouseX, mouseY):
            app.gamePhase = 'MISSION_2'

    elif app.gamePhase == 'MISSION_2':
        if app.inspectedItem == None:
            if app.m2Item1.isHovered(app):
                app.inspectedItem = app.m2Item1
                app.m2Item1.found = True
            elif app.m2Item2.isHovered(app):
                app.inspectedItem = app.m2Item2
                app.m2Item2.found = True
            elif app.m2Item3.isHovered(app):
                app.inspectedItem = app.m2Item3
                app.m2Item3.found = True
        else:
            app.inspectedItem = None
            if app.m2Mission.isListComplete():
                print("MISSION 2 COMPLETE")

def drawInspectionScreen(app):
    drawRect(0, 0, app.width, app.height, fill='black', opacity=75)

    # Draw Inspection Box
    boxX = app.width * 0.05
    boxY = app.height * 0.15
    boxW = app.width * 0.40
    boxH = app.height * 0.75

    # Inspection box and text
    drawRect(boxX, boxY, boxW, boxH, fill='black', border='cyan', borderWidth=2, opacity=85)
    drawLabel(app.inspectedItem.inspectTitle, boxX + 20, boxY + 30, fill='magenta', size=24, bold=True, align='left', font='monospace')
    
    textY = boxY + 75
    for line in app.inspectedItem.inspectText:
        drawLabel(line, boxX + 20, textY, fill='white', size=18, align='left')
        textY += 30

    drawLabel(">> CLICK ANYWHERE TO CLOSE", boxX + boxW - 20, boxY + boxH - 20, fill='cyan', size=14, align='right', font='monospace')

    zoomH = app.height * 0.60
    zoomW = zoomH * app.inspectedItem.aspect
    drawImage(app.inspectedItem.cmuImg, app.width * 0.72, app.height/2, align='center', width=zoomW, height=zoomH)

def redrawAll(app):
    drawRect(0, 0, app.width, app.height, fill = 'black')
    if app.gamePhase == 'TITLESCREEN':
        cellSize = int(app.width * 0.025) 
        
        for x in range(0, app.width, cellSize):
            drawLine(x, 0, x, app.height, fill='cyan', lineWidth=1)
        for y in range(0, app.height, cellSize):
            drawLine(0, y, app.width, y, fill='cyan', lineWidth=1)
            
        drawLine(0, app.height * 0.12, app.width, app.height * 0.12, fill = 'darkSlateGray')
        drawLine(0, app.height * 0.88, app.width, app.height * 0.88, fill = 'darkSlateGray')
        titleSize = app.width * 0.09
        drawLabel("PARALLAX", app.width / 2, app.height * 0.25, fill = 'cyan', size = titleSize, bold = True)

        buttons = [app.playButton, app.savesButton, app.quitButton]
        for btn in buttons:
            if btn.checkClicked(app, app.mouseX, app.mouseY):
                liveX = app.width * btn.cxRatio
                liveY = app.height * btn.cyRatio
                
                drawRect(liveX, liveY, app.width * 0.3, app.height * 0.06, fill='black', align='center')
                
                btnFontSize = app.width * 0.04
                drawLabel(btn.label, liveX, liveY, fill='magenta', size=btnFontSize, font='monospace')

    elif app.gamePhase == 'MISSION_1_BRIEF':
        drawRect(0, 0, app.width, app.height, fill='black')
        drawLabel("MISSION 1: THE PERFECT PREDICTION", app.width / 2, app.height * 0.3, fill='cyan', size=40, font='monospace', bold=True)
        
        drawLabel("SUBJECT: UNIDENTIFIED MALICIOUS ACTOR", app.width / 2, app.height * 0.45, fill='white', size=24, font='monospace')
        drawLabel("LOCATION: SECTOR 4 TRANSIT HUB", app.width / 2, app.height * 0.52, fill='white', size=24, font='monospace')
        drawLabel("THREAT: 100% (IMMINENT EXPLOSIVE EVENT)", app.width / 2, app.height * 0.59, fill='red', size=24, font='monospace')
        
        # Draw the Start Mission 1 Button
        btnX = app.width * app.startM1Button.cxRatio
        btnY = app.height * app.startM1Button.cyRatio
        btnW = app.width * app.startM1Button.wRatio
        btnH = app.height * app.startM1Button.hRatio
        
        btnFill = 'darkSlateGray' if app.startM1Button.checkClicked(app, app.mouseX, app.mouseY) else 'black'
        drawRect(btnX, btnY, btnW, btnH, fill=btnFill, border='cyan', align='center', borderWidth=2)
        drawLabel(app.startM1Button.label, btnX, btnY, fill='cyan', size=20, font='monospace', bold=True)


    elif app.gamePhase == 'MISSION_1':
        # BG
        drawImage(app.officeBG, 0, 0)
        if not app.inDialogue:
            app.androidCoworker.draw(app)
        else:
            # Dialogue Mode
            drawRect(0, 0, app.width, app.height, fill='black', opacity=75)
            zoomH = app.height * 1.4
            zoomW = zoomH * (771/2531)
            drawImage(app.androidCoworker.cmuImg, app.width * 0.8, app.height + 400, align='bottom', width=zoomW, height=zoomH)
            
            # Draw Dialogue Box
            boxX = app.width * 0.05
            boxY = app.height * 0.15
            boxW = app.width * 0.55
            boxH = app.height * 0.25
            
            # Dialogue box and text
            drawRect(boxX, boxY, boxW, boxH, fill='black', border='cyan', borderWidth=2, opacity=85)
            drawLabel("Z3R0_UNIT:", boxX + 20, boxY + 30, fill='magenta', size=24, bold=True, align='left', font='monospace')
            drawLabel("Z3R0 TO S4BL3. Suspicious activity detected near the transit lines.", boxX + 20, boxY + 75, fill='white', size=18, align='left')
            drawLabel("Internal logs indicate a breach originating from the janitor's closet. ", boxX + 20, boxY + 110, fill='white', size=18, align='left')
            drawLabel("Investigate?", boxX + 20, boxY + 145, fill='white', size=18, align='left')
            drawLabel(">> CLICK ANYWHERE TO CLOSE", boxX + boxW - 20, boxY + boxH - 20, fill='cyan', size=14, align='right', font='monospace')

            btnX = app.width * app.closetButton.cxRatio
            btnY = app.height * app.closetButton.cyRatio
            btnW = app.width * app.closetButton.wRatio
            btnH = app.height * app.closetButton.hRatio

            btnFill = 'darkSlateGray' if app.closetButton.checkClicked(app, app.mouseX, app.mouseY) else 'black'
            drawRect(btnX, btnY, btnW, btnH, fill=btnFill, border='cyan', align='center')
            drawLabel(app.closetButton.label, btnX, btnY, fill='cyan', size=14, font='monospace', bold=True)


    elif app.gamePhase == 'MISSION_1_CLOSET':
        drawImage(app.closetBG, 0, 0)
        if app.inspectedItem == None:
            drawLabel("You have entered the janitor's closet.", app.width / 2, app.height * 0.1, fill='gray', size=24, font ='monospace')
            app.backpack.draw(app)
            app.datapad.draw(app)
            app.datachip.draw(app)
        else:
            drawInspectionScreen(app)


    elif app.gamePhase in ['M1_TERMINAL_EVAL', 'M1_TERMINAL_WAIT_DETAIN', 'M1_TERMINAL_EXECUTE']:
            drawRect(0, 0, app.width, app.height, fill='black')
    
            textY = app.height * 0.15
            for line in app.visibleLines:
                drawLabel(line, app.width * 0.05, textY, fill='lime', size=20, font='monospace', align='left')
                textY += 35
                
            # Draw the Detain Button once evaluating is done
            if app.gamePhase == 'M1_TERMINAL_WAIT_DETAIN':
                btnX = app.width * app.detainButton.cxRatio
                btnY = app.height * app.detainButton.cyRatio
                btnW = app.width * app.detainButton.wRatio
                btnH = app.height * app.detainButton.hRatio
    
                btnFill = 'darkSlateGray' if app.detainButton.checkClicked(app, app.mouseX, app.mouseY) else 'black'
                drawRect(btnX, btnY, btnW, btnH, fill=btnFill, border='cyan', align='center')
                drawLabel(app.detainButton.label, btnX, btnY, fill='cyan', size=14, font='monospace', bold=True)
    
    
    elif app.gamePhase == 'MISSION_2_BRIEF':
        drawRect(0, 0, app.width, app.height, fill='black')
        drawLabel("MISSION 2: THE FALSE POSITIVE", app.width / 2, app.height * 0.3, fill='cyan', size=40, font='monospace', bold=True)
        drawLabel("SUBJECT: Lyra Venn, Age 27", app.width / 2, app.height * 0.45, fill='white', size=24, font='monospace')
        drawLabel("LOCATION: Residential District 7 — Apt 18C", app.width / 2, app.height * 0.52, fill='white', size=24, font='monospace')
        drawLabel("THREAT: 89% (Potential Violent Offender)", app.width / 2, app.height * 0.59, fill='magenta', size=24, font='monospace')

        btnX = app.width * app.startM2Button.cxRatio
        btnY = app.height * app.startM2Button.cyRatio
        btnW = app.width * app.startM2Button.wRatio
        btnH = app.height * app.startM2Button.hRatio
        
        btnFill = 'darkSlateGray' if app.startM2Button.checkClicked(app, app.mouseX, app.mouseY) else 'black'
        drawRect(btnX, btnY, btnW, btnH, fill=btnFill, border='cyan', align='center', borderWidth=2)
        drawLabel(app.startM2Button.label, btnX, btnY, fill='cyan', size=20, font='monospace', bold=True)

    elif app.gamePhase == 'MISSION_2':
        if app.inspectedItem == None:
            drawImage(app.aptBG, 0, 0)
            drawLabel("Search the apartment for contraband.", app.width / 2, app.height * 0.1, fill='cyan', size=24, font='monospace', bold=True)

            isHoveringEvidence = False
            for item in app.m2Mission.evidenceList:
                cx = app.width * item.cxRatio
                cy = app.height * item.cyRatio
                w = app.width * item.wRatio
                h = app.height * item.hRatio
                left = cx - (w / 2)
                top = cy - (h / 2)
                
                drawRect(left, top, w, h, fill=None, border='red', borderWidth=2)
                drawLabel(item.inspectTitle, cx, cy, fill='red', size=12, font='monospace', bold=True)

                if item.isHovered(app):
                    isHoveringEvidence = True

            # Draw robot hand icon next to cursor when hovering evidence
            if isHoveringEvidence:
                drawImage(app.robotHand, app.mouseX + 20, app.mouseY + 20, align='center')
        
        else:
            drawImage(app.aptBG, 0, 0) 
            drawInspectionScreen(app)

runApp(width=1100, height=800)


