# PARALLAX
PARALLAX is a 2D investigative point and click narrative game where you play as S4BL3, an android detective tasked with scanning crime scenes, analyzing evidence, and making critical judgments about suspects. The game features interactive UI elements, dynamic object inspection overlays, and state-driven scene transitions. 

## Video Demo
https://youtu.be/SnR6c48kGGk

## How to Run the Project
1. Download or clone the repository to your local machine.
2. Ensure that all asset files (e.g. m2bg.jpg) are located in the same directory as the main Python script.
3. Run the main file using cmd + b.
4. The game relies entirely on mouse interactions. Click the UI buttons to navigate and click on evidence hitboxes to inspect items.

## Required Libraries
* cmu_graphics, Pillow (PIL)

## Shortcut Commands
None
